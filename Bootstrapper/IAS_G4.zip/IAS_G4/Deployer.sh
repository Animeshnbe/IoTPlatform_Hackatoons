printf "\n\n"
echo "Deploying Deployer.........."
printf "\n\n"
path="./Deployer"

gnome-terminal --title="Deployer" -e "bash -c \
\"cd ${path}; \
printf \"********************************************************\"; \
echo ---------------------- Deployer -------------------------; \
printf \"********************************************************\"; \
sudo docker build . -t Deployer:latest; \
sudo docker run Deployer; \
cd ..; \
bash\""