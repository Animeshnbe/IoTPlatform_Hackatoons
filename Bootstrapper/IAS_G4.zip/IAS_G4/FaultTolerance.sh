printf "\n\n"
echo "Deploying Fault Tolerance.........."
printf "\n\n"
path="./FaultTolerance"

gnome-terminal --title="FaultTolerance" -e "bash -c \
\"cd ${path}; \
printf \"********************************************************\"; \
echo ---------------------- Fault Tolerance -------------------------; \
printf \"********************************************************\"; \
sudo docker build . -t FaultTolerance:latest; \
sudo docker run FaultTolerance; \
cd ..; \
bash\""