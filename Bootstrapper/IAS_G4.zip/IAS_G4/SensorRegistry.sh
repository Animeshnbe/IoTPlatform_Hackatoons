printf "\n\n"
echo "Deploying Sensor Registry.........."
printf "\n\n"
path="./SensorRegistry"

gnome-terminal --title="SensorRegistry" -e "bash -c \
\"cd ${path}; \
printf \"********************************************************\"; \
echo ---------------------- Sensor Registry -------------------------; \
printf \"********************************************************\"; \
sudo docker build . -t SensorRegistry:latest; \
sudo docker run SensorRegistry; \
cd ..; \
bash\""