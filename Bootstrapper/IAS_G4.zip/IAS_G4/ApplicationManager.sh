printf "\n\n"
echo "Deploying Application Manager.........."
printf "\n\n"
path="./ApplicationManager"

gnome-terminal --title="ApplicationManager" -e "bash -c \
\"cd ${path}; \
printf \"********************************************************\"; \
echo ---------------------- Application Manager -------------------------; \
printf \"********************************************************\"; \
sudo docker build . -t ApplicationManager:latest; \
sudo docker run ApplicationManager; \
cd ..; \
bash\""