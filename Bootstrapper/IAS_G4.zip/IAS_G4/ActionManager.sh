printf "\n\n"
echo "Deploying Action Manager.........."
printf "\n\n"
path="./ActionManager"

gnome-terminal --title="ActionManager" -e "bash -c \
\"cd ${path}; \
printf \"********************************************************\"; \
echo ---------------------- Action Manager -------------------------; \
printf \"********************************************************\"; \
sudo docker build . -t ActionManager:latest; \
sudo docker run ActionManager; \
cd ..; \
bash\""