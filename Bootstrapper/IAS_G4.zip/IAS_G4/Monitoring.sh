printf "\n\n"
echo "Deploying Monitoring.........."
printf "\n\n"
path="./Monitoring"

gnome-terminal --title="Monitoring" -e "bash -c \
\"cd ${path}; \
printf \"********************************************************\"; \
echo ---------------------- Monitoring -------------------------; \
printf \"********************************************************\"; \
sudo docker build . -t Monitoring:latest; \
sudo docker run Monitoring; \
cd ..; \
bash\""