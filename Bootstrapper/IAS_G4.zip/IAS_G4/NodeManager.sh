printf "\n\n"
echo "Deploying Node Manager.........."
printf "\n\n"
path="./NodeManager"

gnome-terminal --title="NodeManager" -e "bash -c \
\"cd ${path}; \
printf \"********************************************************\"; \
echo ---------------------- Node Manager -------------------------; \
printf \"********************************************************\"; \
sudo docker build . -t NodeManager:latest; \
sudo docker run NodeManager; \
cd ..; \
bash\""
